RestaurantOS V5 - PHONE + LAPTOP READY

This version is a self-contained responsive website demo. It uses browser localStorage, so it can be opened without Node.js for demonstration.

PHONE:
1. Extract the ZIP with your Android file manager.
2. Open index.html in a browser if your file manager/browser supports local HTML files.
3. For the best experience, upload the folder to GitHub Pages, Netlify, or another static host and open the resulting HTTPS link.

LAPTOP:
Open index.html in Chrome/Edge, or host the folder with any static web server.

IMPORTANT:
This V5 is a front-end demo. Payment, QR routing, realtime kitchen synchronization, authentication and server/database persistence are simulated in the browser. For production, connect it to the V4/V5 backend and a real database/payment gateway.
