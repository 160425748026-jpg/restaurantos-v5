# RestaurantOS V5 — Hosting Ready

This package is prepared as a static website for phone + laptop viewing.

## Phone-only publishing (GitHub Pages)
1. Create/sign in to GitHub in Chrome.
2. Create a new repository, for example `restaurantos-v5`.
3. Upload ALL files in this folder.
4. Open the repository's **Settings → Pages**.
5. Select **Deploy from a branch**.
6. Select `main` and `/ (root)`, then Save.
7. GitHub will provide an `https://...github.io/...` website link.

## Important
This hosting-ready build is for the browser demo. A real commercial system needs a secure backend/database, authentication, real payment gateway/webhook verification, HTTPS configuration, and server-side order synchronization.
